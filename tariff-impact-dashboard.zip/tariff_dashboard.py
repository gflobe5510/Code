import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import io

# Simulate realistic trade data with seasonal effects
@st.cache_data
def generate_mock_data():
    np.random.seed(42)
    start_date = datetime(2021, 1, 1)
    end_date = datetime(2024, 1, 1)
    dates = pd.date_range(start_date, end_date, freq='MS')
    countries = ['USA', 'China', 'Germany', 'Brazil']
    products = ['Steel', 'Aluminum', 'Electronics']

    data = []
    for date in dates:
        for country in countries:
            for product in products:
                base_value = np.random.uniform(100, 200)
                seasonality = 10 * np.sin(2 * np.pi * (date.month / 12))
                tariff_rate = 0.0
                if product == 'Steel' and country == 'USA' and date >= datetime(2022, 3, 1):
                    tariff_rate = 0.25  # Simulate US tariff on steel
                elasticity = -0.5
                volume = base_value * (1 + seasonality / 100) * (1 + elasticity * tariff_rate)
                value = volume * (1 + tariff_rate)
                data.append([date, country, product, volume, value, tariff_rate])

    df = pd.DataFrame(data, columns=['Date', 'Country', 'Product', 'Volume', 'Value', 'TariffRate'])
    return df

# App entry
st.title("📊 Tariff Impact Dashboard")
df = generate_mock_data()

st.sidebar.header("Filters")
selected_countries = st.sidebar.multiselect("Select Countries", df['Country'].unique(), default=list(df['Country'].unique()))
selected_products = st.sidebar.multiselect("Select Products", df['Product'].unique(), default=list(df['Product'].unique()))
custom_tariff = st.sidebar.slider("Apply Custom Tariff Rate (All Countries, All Products)", 0.0, 0.5, 0.0, 0.01)

# Apply filters and custom tariff override
df_filtered = df[df['Country'].isin(selected_countries) & df['Product'].isin(selected_products)].copy()
if custom_tariff > 0:
    df_filtered['TariffRate'] = custom_tariff
    df_filtered['Volume'] = df_filtered['Volume'] * (1 - 0.5 * custom_tariff)
    df_filtered['Value'] = df_filtered['Volume'] * (1 + custom_tariff)

# Tabs
tab1, tab2, tab3 = st.tabs(["📈 Time Trends", "🌍 Country Comparison", "📦 Product Charts"])

with tab1:
    st.subheader("Trade Value Over Time")
    fig = px.line(
        df_filtered,
        x='Date',
        y='Value',
        color='Country',
        line_dash='Product',
        title='Monthly Trade Value by Country and Product',
        hover_data=['Product', 'TariffRate']
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Average Tariff Rate Over Time")
    avg_tariff = df_filtered.groupby(['Date', 'Country'])['TariffRate'].mean().reset_index()
    fig2 = px.line(
        avg_tariff,
        x='Date',
        y='TariffRate',
        color='Country',
        title='Average Tariff Rate by Country Over Time'
    )
    st.plotly_chart(fig2, use_container_width=True)

with tab2:
    st.subheader("Total Trade Volume by Country")
    volume_by_country = df_filtered.groupby('Country')['Volume'].sum().reset_index()
    fig3 = px.bar(volume_by_country, x='Country', y='Volume', title='Total Trade Volume by Country')
    st.plotly_chart(fig3, use_container_width=True)

    st.subheader("Total Trade Value by Country")
    value_by_country = df_filtered.groupby('Country')['Value'].sum().reset_index()
    fig4 = px.bar(value_by_country, x='Country', y='Value', title='Total Trade Value by Country')
    st.plotly_chart(fig4, use_container_width=True)

with tab3:
    st.subheader("Trade Breakdown by Product")
    for product in selected_products:
        product_df = df_filtered[df_filtered['Product'] == product]
        if not product_df.empty:
            fig = px.line(
                product_df,
                x='Date',
                y='Value',
                color='Country',
                title=f'Trade Value Over Time for {product}',
                hover_data=['TariffRate']
            )
            st.plotly_chart(fig, use_container_width=True)

# Preview filtered data
with st.expander("🔍 Preview Filtered Data"):
    st.dataframe(df_filtered.head(100))

# Download/export feature
st.sidebar.header("Export Data")
export_format = st.sidebar.selectbox("Choose Export Format", ["CSV", "Excel", "JSON"])

if export_format == "CSV":
    data = df_filtered.to_csv(index=False).encode('utf-8')
    mime = 'text/csv'
    file_name = 'filtered_tariff_data.csv'
elif export_format == "Excel":
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df_filtered.to_excel(writer, index=False, sheet_name='TariffData')
    data = output.getvalue()
    mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    file_name = 'filtered_tariff_data.xlsx'
elif export_format == "JSON":
    data = df_filtered.to_json(orient='records').encode('utf-8')
    mime = 'application/json'
    file_name = 'filtered_tariff_data.json'

st.sidebar.download_button(
    label=f"Download Filtered Data as {export_format}",
    data=data,
    file_name=file_name,
    mime=mime
)

st.caption("Data is simulated for illustrative purposes. Custom tariffs apply uniformly and override existing ones.")
