# 📊 Tariff Impact Dashboard

## Overview
This Streamlit application simulates and visualizes international trade data to analyze the impact of tariffs over time. It includes interactive filters, customizable tariff settings, and exportable data views. The data is entirely synthetic and meant for illustrative or educational use.

---

## 🚀 Features
- **Realistic Simulated Trade Data** (2021–2024)
- **Custom Tariff Rate**: Apply a user-defined tariff to all trade.
- **Interactive Filtering**: Select countries and product categories.
- **Dynamic Visualizations**:
  - Time series of trade value and tariffs
  - Country-by-country volume/value comparisons
  - Per-product trade breakdowns
- **Data Preview and Export**:
  - Export data as CSV, Excel, or JSON
  - Preview top 100 rows of filtered results

---

## 📁 Folder Structure
```
📦 tariff-impact-dashboard
├── tariff_dashboard.py        # Main Streamlit app script
├── README.md                  # Project overview and usage instructions
└── requirements.txt           # Python dependencies (to be created)
```

---

## 🛠️ Installation
```bash
# 1. Clone the repository
$ git clone https://github.com/yourusername/tariff-impact-dashboard.git
$ cd tariff-impact-dashboard

# 2. (Recommended) Create a virtual environment
$ python -m venv venv
$ source venv/bin/activate  # or venv\Scripts\activate on Windows

# 3. Install dependencies
$ pip install -r requirements.txt
```

---

## ▶️ Running the App
```bash
streamlit run tariff_dashboard.py
```

Then, open your browser to `http://localhost:8501` (or the URL shown in your terminal).

---

## 📥 Exporting Data
Use the sidebar:
- Select the format (CSV, Excel, JSON)
- Click the **"Download Filtered Data"** button

The export will match any filters and custom tariffs you've applied.

---

## 📌 Requirements
- Python 3.8+
- Packages:
  - `streamlit`
  - `pandas`
  - `numpy`
  - `plotly`
  - `xlsxwriter`

You can install them all using the provided `requirements.txt` file.

---

## 📃 License
This project is licensed under the MIT License.

---

## 🙌 Acknowledgments
Created by [Your Name] for educational and demo purposes.

---

For suggestions or contributions, feel free to fork and open a pull request!
