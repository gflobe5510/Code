# AI-Powered CFA Level I Quiz Generator

## Slide 1: Project Overview
- Intelligent quiz tool for CFA Level I exam prep
- Supports math, charts, and image-enhanced questions
- Combines Flask, React, and AI technologies

---

## Slide 2: Why This Project?
- Traditional CFA prep is static and repetitive
- Learners need:
  - Personalized practice
  - Instant feedback
  - Engaging visuals
- This app meets those needs

---

## Slide 3: Key Features
- Topic selection and question generation
- Support for LaTeX formulas, charts, and images
- Four chart types: line, bar, area, pie
- Real-time answer checking
- Future OpenAI integration for dynamic content

---

## Slide 4: Architecture
**Frontend**
- React + Tailwind UI
- Recharts for data viz
- Markdown + KaTeX for math and formatting

**Backend**
- Flask + CORS
- Chart template generator
- JSON API for quiz content

**Deployment**
- Docker + Docker Compose
- Full-stack containerized setup

---

## Slide 5: Example API Response
```json
{
  "question": "Analyze the chart.",
  "option_A": "Growth",
  "option_B": "Decline",
  "option_C": "Random",
  "answer": "A",
  "chartType": "line",
  "chartData": [
    {"x": "Q1", "y": 10},
    {"x": "Q2", "y": 30},
    {"x": "Q3", "y": 60}
  ]
}
```

---

## Slide 6: Workflow
1. User selects topic and number of questions
2. Backend generates questions (static for now)
3. Frontend displays question and chart
4. User selects answer and gets feedback

---

## Slide 7: Docker Setup
- Backend in `backend/` folder
- Compose file coordinates frontend and backend
- Command:
```bash
  docker-compose up --build
```
- Runs full app on localhost ports 3000/5001

---

## Slide 8: Future Enhancements
- Integrate GPT-based PDF extraction and question generation
- Add user scoring dashboard
- Enable content moderation and tagging

---

## Slide 9: Summary
- Smart, interactive CFA prep tool
- Visual, adaptive, and modern
- Built to scale and evolve with learners' needs

---

## Slide 10: Let's Build Smarter Prep Tools 🚀
- Thank you!
