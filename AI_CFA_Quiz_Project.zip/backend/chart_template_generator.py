import random
import json

def generate_chart_question_template(topic="Quantitative Methods", chart_type="line"):
    base_question = "Analyze the following chart and answer the question."

    options = [
        "A) The trend shows exponential growth.",
        "B) The data indicates a linear decline.",
        "C) The values fluctuate randomly with no pattern."
    ]
    answer = "A"
    explanation = "The data reflects exponential growth as per the CFA curriculum section on time-series analysis."

    if chart_type == "pie":
        chart_data = [
            {"name": "Equity", "value": random.randint(20, 50)},
            {"name": "Fixed Income", "value": random.randint(10, 30)},
            {"name": "Cash", "value": random.randint(5, 20)}
        ]
    else:
        chart_data = [
            {"x": f"Q{i+1}", "y": random.randint(10, 100)}
            for i in range(5)
        ]

    return {
        "topic": topic,
        "question": base_question,
        "option_A": options[0],
        "option_B": options[1],
        "option_C": options[2],
        "answer": answer,
        "explanation": explanation,
        "chartType": chart_type,
        "chartData": chart_data
    }

if __name__ == "__main__":
    template = generate_chart_question_template(chart_type="area")
    print(json.dumps(template, indent=2))
