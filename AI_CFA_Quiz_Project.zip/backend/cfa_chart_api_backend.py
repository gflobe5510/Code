
from flask import Flask, request, jsonify
from flask_cors import CORS
from chart_template_generator import generate_chart_question_template

app = Flask(__name__)
CORS(app)  # allow frontend to call this backend

@app.route("/api/generate-chart-questions", methods=["POST"])
def generate_chart_questions():
    data = request.get_json()
    topic = data.get("topic", "Quantitative Methods")
    chart_type = data.get("chartType", "line")
    count = int(data.get("count", 1))

    questions = [generate_chart_question_template(topic, chart_type) for _ in range(count)]
    return jsonify(questions)

if __name__ == "__main__":
    app.run(debug=True, port=5001)
