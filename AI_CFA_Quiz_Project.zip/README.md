# CFA Level I AI Quiz Generator

An AI-powered web app that generates dynamic CFA Level I practice questions with charts, formulas, and real-time feedback. Designed for candidates seeking an interactive and customizable study experience.

## 🚀 Features
- AI-generated and template-based multiple-choice questions (MCQs)
- Support for images, LaTeX math, and chart visualizations (line, bar, area, pie)
- React frontend with real-time answer checking and chart rendering (Recharts)
- Flask backend API with static chart question generator
- Dockerized setup and optional Docker Compose for full-stack orchestration

## 🧱 Tech Stack
- **Frontend**: React, Tailwind CSS, Recharts, React Markdown, KaTeX
- **Backend**: Python, Flask, Flask-CORS
- **AI**: OpenAI (planned)
- **Deployment**: Docker, Docker Compose

## 📂 Project Structure
```
/cfa_quiz_project
├── backend
│   ├── chart_template_generator.py
│   ├── cfa_chart_api_backend.py
│   └── Dockerfile
├── frontend
│   └── (React app placeholder)
├── docker-compose.yml
└── Cfa_Quiz_Project_Paper.pdf
```

## 📊 API Endpoint
### `POST /api/generate-chart-questions`
**Payload:**
```json
{
  "topic": "Quantitative Methods",
  "chartType": "bar",
  "count": 3
}
```
**Response:**
List of question objects with text, answer, explanation, chart type, and chart data.

## 🐳 Docker Usage
```bash
# Build and run backend only
cd backend
docker build -t cfa-chart-backend .
docker run -p 5001:5001 cfa-chart-backend

# Or start both frontend and backend
cd ..
docker-compose up --build
```

## 🔮 Planned Features
- OpenAI integration for PDF-based live question generation
- User auth and scoring dashboard
- Admin panel to manage question generation logic

## 🧠 Authors
Developed by an educator and developer focused on transforming exam prep through AI and modern web technologies.

## 📄 Documentation
See `Cfa_Quiz_Project_Paper.pdf` for a full explanation of the system.

---

> Ready to study smarter, not harder. 💡
