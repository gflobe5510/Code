# Dynamic Pricing App
Refactored Flask + Streamlit integration project.